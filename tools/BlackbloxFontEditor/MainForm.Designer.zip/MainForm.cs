using BlackbloxFontEditor.Controls;
using BlackbloxFontEditor.Generators;
using BlackbloxFontEditor.Models;
using BlackbloxFontEditor.Importers;

namespace BlackbloxFontEditor;

public partial class MainForm : Form
{
    private readonly PixelGrid _grid;
    private readonly TextBox _characterBox;
    private readonly Button _clearButton;
    private readonly Button _generateButton;
    private readonly Button _importBdfButton;
    private readonly TextBox _outputBox;
    private readonly FontResource _font;
    private readonly Button _nextButton;
    private readonly Button _previousButton;

    public MainForm()
    {
        InitializeComponent();

        Text = "BLACKBLOX Font Editor";
        ClientSize = new Size(900, 650);
        StartPosition = FormStartPosition.CenterScreen;

        Label characterLabel = new Label
        {
            Left = 20,
            Top = 24,
            Width = 90,
            Text = "Character:"
        };

        _characterBox = new TextBox
        {
            Left = 120,
            Top = 20,
            Width = 50,
            Text = "A",
            MaxLength = 1
        };

        _font = new FontResource();

        _grid = new PixelGrid
        {
            Left = 20,
            Top = 60,
            Width = 350,
            Height = 490
        };

        _grid.SetGlyph(_font.GetGlyph('A'));

        _clearButton = new Button
        {
            Left = 20,
            Top = 570,
            Width = 100,
            Height = 35,
            Text = "Clear"
        };

        _generateButton = new Button
        {
            Left = 130,
            Top = 570,
            Width = 120,
            Height = 35,
            Text = "Generate C++"
        };

        _previousButton = new Button
        {
            Left = 260,
            Top = 570,
            Width = 50,
            Height = 35,
            Text = "<"
        };

        _nextButton = new Button
        {
            Left = 320,
            Top = 570,
            Width = 50,
            Height = 35,
            Text = ">"
        };

        _importBdfButton = new Button
        {
            Left = 400,
            Top = 570,
            Width = 120,
            Height = 35,
            Text = "Import BDF"
        };

        _outputBox = new TextBox
        {
            Left = 400,
            Top = 60,
            Width = 470,
            Height = 490,
            Multiline = true,
            ScrollBars = ScrollBars.Both,
            Font = new Font("Consolas", 10),
            WordWrap = false
        };

        _characterBox.TextChanged += CharacterBox_TextChanged;
        _characterBox.KeyDown += CharacterBox_KeyDown;

        _clearButton.Click += ClearButton_Click;
        _generateButton.Click += GenerateButton_Click;
        _importBdfButton.Click += ImportBdfButton_Click;
        _nextButton.Click += NextButton_Click;
        _previousButton.Click += PreviousButton_Click;

        Controls.Add(characterLabel);
        Controls.Add(_characterBox);
        Controls.Add(_grid);
        Controls.Add(_clearButton);
        Controls.Add(_generateButton);
        Controls.Add(_previousButton);
        Controls.Add(_nextButton);
        Controls.Add(_importBdfButton);
        Controls.Add(_outputBox);
    }

    private void ClearButton_Click(object? sender, EventArgs e)
    {
        _font.GetGlyph(CurrentCharacter).Clear();

        _grid.Invalidate();
        _outputBox.Clear();
    }

    private void GenerateButton_Click(object? sender, EventArgs e)
    {
        if (_characterBox.TextLength != 1)
            return;

        if (_grid.Glyph is null)
            return;

        string name = $"font5x7_{CurrentCharacter}";

        _outputBox.Text = CppGenerator.Generate(
            _grid.Glyph,
            name);

        _outputBox.SelectAll();
        _outputBox.Focus();
    }

    private void ImportBdfButton_Click(object? sender, EventArgs e)
    {
        using OpenFileDialog dialog = new()
        {
            Filter = "BDF font files (*.bdf)|*.bdf|All files (*.*)|*.*",
            Title = "Import BDF Font"
        };

        if (dialog.ShowDialog() == DialogResult.OK)
        {

            int importedGlyphs = BdfImporter.Import(
                dialog.FileName,
                _font);

            _grid.SetGlyph(_font.GetGlyph(CurrentCharacter));
            _grid.Invalidate();

            MessageBox.Show(
                $"Uvoženih znakov: {importedGlyphs}",
                "BDF Import");
        }
    }

    private void CharacterBox_TextChanged(object? sender, EventArgs e)
    {
        if (_characterBox.Text.Length != 1)
            return;

        _grid.SetGlyph(_font.GetGlyph(CurrentCharacter));
        _outputBox.Clear();
    }

    private void SelectCharacter(char c)
    {
        if (_characterBox.Text == c.ToString())
            return;

        _characterBox.Text = c.ToString();
    }

    private void NextButton_Click(object? sender, EventArgs e)
    {
        if (_characterBox.Text.Length != 1)
            return;

        char c = CurrentCharacter;

        c = c >= '~'
            ? ' '
            : (char)(c + 1);

        SelectCharacter(c);
        _characterBox.Focus();
    }

    private void PreviousButton_Click(object? sender, EventArgs e)
    {
        if (_characterBox.Text.Length != 1)
            return;

        char c = CurrentCharacter;

        c = c <= ' '
            ? '~'
            : (char)(c - 1);

        SelectCharacter(c);
        _characterBox.Focus();
    }

    private void CharacterBox_KeyDown(object? sender, KeyEventArgs e)
    {
        if (e.KeyCode != Keys.Enter)
            return;

        GenerateButton_Click(null, EventArgs.Empty);

        e.SuppressKeyPress = true;
    }

    private char CurrentCharacter => _characterBox.Text[0];
}